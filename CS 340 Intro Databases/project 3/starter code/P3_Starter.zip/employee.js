// add functions and routes here
// use people.js as example from other starter codes

// base functions you will need:

// function getProjects
// function getEmployees
// function getByProject
// function getProjectInfo
// function getByName
// router.get('/'
// router.get('/filter/:project'
// router.get('/search/:s'
