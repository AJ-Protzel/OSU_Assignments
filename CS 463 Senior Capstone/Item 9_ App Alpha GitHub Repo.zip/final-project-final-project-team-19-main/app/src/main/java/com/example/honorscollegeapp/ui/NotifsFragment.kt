package com.example.honorscollegeapp.ui

import androidx.fragment.app.Fragment
import com.example.honorscollegeapp.R

class NotifsFragment : Fragment(R.layout.page_notifications) {

}