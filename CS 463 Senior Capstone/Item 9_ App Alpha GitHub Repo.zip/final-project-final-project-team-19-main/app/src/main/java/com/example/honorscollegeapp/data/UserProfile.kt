package com.example.honorscollegeapp.data

class UserProfile {
//    var UserEmail: String
}