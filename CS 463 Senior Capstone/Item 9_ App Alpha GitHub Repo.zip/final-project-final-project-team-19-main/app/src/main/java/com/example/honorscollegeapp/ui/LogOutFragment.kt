package com.example.honorscollegeapp.ui

import androidx.fragment.app.Fragment
import com.example.honorscollegeapp.R

// Not really sure if this is needed or how it will work

//class LogOutFragment : Fragment(R.layout.logout) {
//
//}