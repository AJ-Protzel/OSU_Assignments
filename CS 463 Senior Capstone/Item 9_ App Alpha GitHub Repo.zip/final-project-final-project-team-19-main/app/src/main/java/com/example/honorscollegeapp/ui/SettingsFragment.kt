package com.example.honorscollegeapp.ui

import androidx.fragment.app.Fragment
import com.example.honorscollegeapp.R

class SettingsFragment : Fragment(R.layout.page_settings) {

}