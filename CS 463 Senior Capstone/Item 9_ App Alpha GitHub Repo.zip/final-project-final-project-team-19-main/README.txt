This app is an alpha version of the high fidelity proto type as shown in the Box.
This was initially a final project for CS 492 Mobile Software Development W2022, and so it was modified to complete requirements in that assignment. The code structure is also based on notes given to us during the CS492 class.

The purpose of this app alpha was first an assignment to turn in for CS492 and second, a demonstration on how this app might look when implemented although the final high fidelity Figma was not fully implemented due to time and skill constraints. The high fidelity Figma (link found in the Box) should be seen as the official app UI, and a more official app created should use that.

This code is a basic framework using kotlin, java, html, and xml. 

![](https://github.com/osu-cs492-w22/final-project-final-project-team-19/blob/main/showcase1.gif)
